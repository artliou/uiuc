# CS445
Name: arthurl3

Prompt: README explaining the file organization and how to run your project (if possible). 

##Organization: 

- finalProject.ipynb

- finalProject.pdf (notebook run after kernal restarted)

- [CS445] Final Project Report.pdf


##Instructions
Requirements: internet, browser, google account

1) Navigate to https://colab.research.google.com/notebooks/intro.ipynb. This will take you to an intro notebook

2) File -> Upload notebook (requires Google Account)

3) Runtime -> Run all