%% improving color/contrast in night image

LINEAR_GAMMA = 0;
USE_REF = 0;
HIST_EQ_VIVID = 1;
close all;

if LINEAR_GAMMA
  fn = '.\scotland_input2.jpg';

  im = im2double(imread(fn)); % read image
  % show image and its histograms
  figure(1), imshow(im);
  img = rgb2gray(im);
  
  r = im(:, :, 1); g = im(:, :, 2); b = im(:, :, 3);
  h = hist(img(:), 0:1/255:1);  
  hr = hist(r(:), 0:1/255:1); hg = hist(g(:), 0:1/255:1); hb = hist(b(:), 0:1/255:1);
  figure(4), hold off, plot(h, 'k'); hold on, plot(hr, 'r'), plot(hg, 'g'), plot(hb, 'b');
  pause;

  % auto/manual linear color balance
  % ref = [0.675 0.761 0.788]; mv = mean(ref); alpha = ref ./ mv;
  if USE_REF
    fprintf('Select the reference gray point: ');
    figure(1)
    [x, y] = ginput(1);
    ref = reshape(im(round(y), round(x), :), [1 3]);
    fprintf('%0.2f %0.2f %0.2f\n', ref);
    mv = mean(ref); 
    alpha = mv ./ ref;
  else
    mv = mean(im(:));  
    alpha = mv ./ [mean(r(:)) mean(g(:)) mean(b(:))];
  end
  im2 = cat(3, r*alpha(1), g*alpha(2), b*alpha(3));
  figure(2), imshow(im2);
  fprintf('Linear Scaling by %0.2f %0.2f %0.2f\n', alpha);
  img2 = rgb2gray(im2);
  r2 = im2(:, :, 1); g2 = im2(:, :, 2); b2 = im2(:, :, 3);
  h2 = hist(img2(:), 0:1/255:1);  
  hr2 = hist(r2(:), 0:1/255:1); hg2 = hist(g2(:), 0:1/255:1); hb2 = hist(b2(:), 0:1/255:1);
  figure(4), plot(h2, 'k.'); plot(hr2, 'r.'), plot(hg2, 'g.'), plot(hb2, 'b.');
  pause;
  
  % gamma correction
  im3 = im2.^0.8;
  figure(3), imshow(im3);
  figure(4), hold off, plot(h2, 'k');
  img3 = rgb2gray(im3);
  h3 = hist(img3(:), 0:1/255:1);  
  figure(4), hold on, plot(h3, 'r-');
end


%% improving contrast and vividness in rainbow shot
if HIST_EQ_VIVID
  fn = '.\scotland_input.jpg';

  im = im2double(imread(fn)); % read image

  % show image and its histograms
  figure(1), imshow(im);
  img = rgb2gray(im);
  [hue, sat, val] = rgb2hsv(im);
  h = hist(val(:), 0:1/255:1);
  figure(4), hold off, plot(h, 'b')
  pause

  % compute cumulative histogram and equalize
  c = cumsum(h);
  val2 = c(uint16(val*255)+1)/numel(val);
  im2 = hsv2rgb(hue, sat, val2);
  figure(2), imshow(im2); % too strong
  figure(4), hold on, plot(h2, '.g');
  pause

  im2 = hsv2rgb(hue, sat, val2*0.5+val*0.5);
  figure(2), imshow(im2);
  h2 = hist(val(:)*0.5 + val2(:)*0.5, 0:1/255:1);
  figure(4), hold on, plot(h2, '.r');
  pause; 
  
  % get mask of region to make colors more vivid
  figure(2)
  [x, y] = ginput;
  mask = poly2mask(x, y, size(val,1), size(val, 2));
  mask2 = imfilter(im2double(mask), fspecial('gaussian', 151, 25));
  im3 = hsv2rgb(hue, (1-mask2).*sat + mask2.*(sat.^0.7), val2*0.5+val*0.5);
  figure(3), imshow(im3);
end